HP Power Manager 4.2 README.TXT

Release Notes for HP Power Manager (Windows Management Server)
October 2007 (Seventh Edition)

-----------------------------------------------------------------------------
Overview
-----------------------------------------------------------------------------
HP Power Manager enables you to monitor, manage, and control power
environments through comprehensive control of individual HP UPSs. A familiar
browser interface provides secure access to Management Servers anywhere on
the network. You can control power failure settings and define UPS load
segments to allow for maximum uptime of critical servers.

The Management Server provides both status and shutdown information to the 
Remote Agent. The Remote Agent runs on a machine and allows the software 
to gracefully shut down the operating system of that server and run a script 
during power failure. Install the Remote Agent on any machine that is powered 
by the UPS and any machine that the software uses to initiate a command. 
However, it is not necessary to install the Remote Agent on the machine 
running the Management Server component.

For a detailed list of supported UPSs, refer to the Supported Hardware matrix
on the HP Power Manager Product Overview page on the HP website
(http://www.hp.com/go/rackandpower/)

You can configure HP Power Manager to send alert traps to HP Systems Insight
Manager and other SNMP management programs. The software can also run as a
stand-alone power management system. This flexibility enables you to monitor,
manage, and communicate with a UPS through a network port, USB port, or
serial port whenever these ports are available as built-in ports or
via option cards.  To facilitate day-to-day maintenance tasks, the software
provides detailed system logs and system diagnostics, including UPS battery
checks.

===============================================
Contents
===============================================

Part	Description
----	-----------
 1	System Requirements 	
 2  	Installation Instructions
 3	Known Issues

===============================================
Part 1: System Requirements
===============================================

Suggested Minimum Requirements


Management Server and Remote Agent Client:

	Processor		500-MHz 
	Disk space 	 	25 MB free disk space
	System memory 	 	128 MB of RAM



	Operating systems (on all platforms: x86, x64, IA64):

	. Microsoft Windows Server 2003 SE/EE R2, SP1/SP2
	. Microsoft Windows Server 2003 SE/EE R1, SP1
	. Microsoft Windows Small Business Server 2003 R2, SP1 
	. Microsoft Windows XP Professional, SP2

	Web browser on a client:	

	� Microsoft� Internet Explorer 6.0 SP1 


	Monitor resolution:		

	� Minimum supported resolution of 1024 x 768
         16-bit high color (maximize browser window 
         for optimal display)

NOTE:  Browsing requires the use of Adobe Flash Player 9.0
       found at: http://www.adobe.com



===============================================
Part 2: Installation Instructions
===============================================

Windows Installation
	
Installing Components on Windows Operating Systems

The Management Server and Remote Agent can be installed using the GUI or
silent installation methods on any supported Windows� operating system.

IMPORTANT: The Management Server and Remote Agent
components cannot be installed on the same computer.

NOTE: You might need to reboot after installing HPPM software.

If the software has been downloaded from the HP website
(http://www.hp.com/go/rackandpower/), follow the instructions to unpack the
files, then locate and run SETUP.EXE.

For detail software installation instructions please refer to the HP Power
Manager User Guide.

NOTE: Before installing the software, be sure that the serial, USB, or
network cable connecting the UPS to the Management Server is properly 
installed.

=========================================================
Part 3: Operational Notes and Known Issues
=========================================================

Windows USB Root Hub settings under Power Management tab
is enabled for power saving by default.  When Windows enters
power save mode the USB port will be turned off and HP Power Manager will
report UPS disconnected.  Users need to disable this setting if using USB
port for UPS monitoring.

When attaching a storage device to a load segment in HP Power Manager the
shutdown OS time for Storage Device  May not be grayed out.  A storage device
should have the longest run time to allow computers accessing the storage 
device to save data before beginning their shutdown. HP Power Manager will 
not allow users to set the Storage Device shutdown time to be less than 
the management server's runtime.

When Installing HP Power Manager on a 64 bit Windows using the interactive
install will land the HP Power Manager files in the x86 Program Files 
directory. The application will still run and should not be moved. However 
silent installs will land the HP Power Manager files in the 64 bit Windows 
program files folder. Again the application will run and files should not 
be moved.

For further details see "Trouble Shooting" section of HP Power Manager 
User's Guide.

